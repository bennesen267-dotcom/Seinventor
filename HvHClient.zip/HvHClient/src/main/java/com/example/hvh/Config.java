package com.example.hvh;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    public boolean totemEnabled = true;
    public boolean autoOpen = true;
    public boolean autoClose = true;
    public boolean hover = true;
    public float health = 8f;
    public int totemSlot = 1;
    public int delay = 2;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("hvhclient.json");
    private static Config instance = new Config();

    public static Config get() { return instance; }

    public static void load() {
        try {
            if (Files.exists(PATH)) {
                Config c = GSON.fromJson(Files.readString(PATH), Config.class);
                if (c != null) instance = c;
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        if (SelfDestruct.done) return;
        try { Files.writeString(PATH, GSON.toJson(instance)); } catch (Exception ignored) {}
    }

    public static void delete() {
        try { Files.deleteIfExists(PATH); } catch (Exception ignored) {}
    }
}
