package com.example.hvh;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class SelfDestruct {
    public static boolean done = false;

    public static void run() {
        done = true;
        Config.delete();
        try {
            FabricLoader.getInstance().getModContainer("hvhclient").ifPresent(c -> {
                for (Path p : c.getOrigin().getPaths()) {
                    if (Files.isRegularFile(p) && p.toString().endsWith(".jar")) removeJar(p);
                }
            });
        } catch (Exception ignored) {}
    }

    private static void removeJar(Path jar) {
        try {
            Files.delete(jar);
        } catch (Exception e) {
            // Windows yüklü jar'ı kilitler: oyun kapandıktan sonra sil
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    String f = jar.toAbsolutePath().toString();
                    boolean win = System.getProperty("os.name").toLowerCase().contains("win");
                    ProcessBuilder pb = win
                            ? new ProcessBuilder("cmd", "/c", "ping -n 4 127.0.0.1 >nul & del /f /q \"" + f + "\"")
                            : new ProcessBuilder("sh", "-c", "sleep 3; rm -f \"" + f + "\"");
                    pb.start();
                } catch (Exception ignored) {}
            }));
        }
    }
}
